from userbot import simpdef


simpmusic = simpdef.simpmusic 
simpmusicvideo = simpdef.simpmusicvideo

